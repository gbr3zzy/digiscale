import React from 'react';
import Dropdown from '../components/Dropdown';
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css';
const options = [
    { key: 'loc2', text: 'Hamiltons Goods' },
    { key: 'loc1', text: 'Rollings Green' }
]
const data = [{ "name": "Blue dream 1/8 oz", "price": "$40.00", "unit": "24% THC", "type": "Hybrid" }, { "name": "Nathans Brownies : Macadamia nut", "price": "$19.99", "unit": "100mg", "type": "Edible" }];


const Products = (props) => {
    const listItems = data.map((d) =>
        <div className="row flexWrap">
            <div className='col-4'>{d.name}</div>
            <div className='col-4 cardBorder'>{d.price}</div>
            <div className='col-4'>{d.unit}</div>
        </div>);
    return (
        <div className='container-fluid mainContainer'>

            <div className="row">
                <Dropdown options={options} />
            </div>
            {listItems}
        </div>
    );
}

export default Products;
