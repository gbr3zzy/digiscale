import React from 'react';

function CreateOrder() {
    return (
        <div className='home'>
            <h1>Create Order</h1>
        </div>
    );
}

export default CreateOrder;